<table id="myTable" class="table table-dark table-hover table-striped align-middle">
  <thead class="table-secondary text-dark">
    <tr>
      <th>No.</th>
      <th>Foto</th>
      <th>NISN</th>
      <th>Nama Lengkap</th>
      <th>Alamat</th>
      <th>Aksi</th>
    </tr>
  </thead>
  <tbody>
    <?php 
      $no = 1;
      $sql = mysqli_query($connect,"SELECT * FROM tbl_siswa");
      while ($r = mysqli_fetch_array($sql)) { 
    ?>
    <tr>
      <td><?= $no++; ?></td>
      <td>
        <img src="foto/<?= $r['foto']; ?>" width="60" class="rounded shadow-sm border border-light">
      </td>
      <td><?= $r['nisn']; ?></td>
      <td><?= $r['nama']; ?></td>
      <td><?= $r['alamat']; ?></td>
      <td>
        <a href="edit.php?id=<?= $r['id_siswa']; ?>" class="btn btn-sm btn-outline-success btn-custom me-1" title="Edit">
          <i class="fas fa-edit"></i>
        </a>
        <a href="process.php?act=hapus&id=<?= $r['id_siswa']; ?>" 
           onclick="return confirm('Yakin akan menghapus data ini?')" 
           class="btn btn-sm btn-outline-danger btn-custom" title="Hapus">
          <i class="fas fa-trash-alt"></i>
        </a>
      </td>
    </tr>
    <?php } ?>
  </tbody>
</table>
