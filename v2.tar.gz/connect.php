<?php
    $server = "127.0.0.1";
    $username = "root";
    $password = "";
    $database = "db_sekolah";
    $connect = mysqli_connect($server, $username, $password,$database);

    if (mysqli_connect_errno()) {
        exit('Failed to connect to MySQL: ' . mysqli_connect_error());
    }
?>
