<?php
    include "connect.php";

    $nama_file = $_FILES['foto']['name'];
    $acak = rand(1,99);
    $nama_file_unik = $acak.$nama_file;

    $nisn = $_POST['nisn'];
    $nama = $_POST['nama'];
    $alamat = $_POST['alamat'];

    if ($_GET['act']=="simpan"){
        if(isset($_POST["submit"])){

            if (!empty($nama_file)){
                move_uploaded_file($_FILES["foto"]["tmp_name"], "foto/".$nama_file_unik);

                $query = mysqli_query($connect, "INSERT INTO tbl_siswa 
                    (nisn,nama,alamat,foto) 
                    values ('$nisn','$nama','$alamat','$nama_file_unik')") 
                or die('Ada kesalahan pada query  : '.mysqli_error($connect));
                if ($query == TRUE){
                    header("location: index.php?alert=1");
                }
            }
        }
    }
    elseif ($_GET['act']=='update') {
        $id = $_POST['id'];
        if (isset($id)) {

            if (!empty($nama_file)){
            $query = "SELECT foto FROM tbl_siswa WHERE id_siswa='$id'";
            $hapus = mysqli_query($connect, $query);
            $r     = mysqli_fetch_array($hapus);
                    if ($r['foto']!=''){
                            $namafile = $r['foto'];
                            unlink("foto/".$namafile); 
                        }  

            move_uploaded_file($_FILES["foto"]["tmp_name"], "foto/".$nama_file_unik);            
            $query = mysqli_query($connect, "UPDATE tbl_siswa 
                SET nisn = '$nisn',
                    nama = '$nama',
                    alamat = '$alamat',
                    foto = '$nama_file_unik' WHERE id_siswa='$id'")or die('Ada kesalahan pada query  : '.mysqli_error($connect));
            }else{
                $query = mysqli_query($connect, "UPDATE tbl_siswa 
                SET nisn = '$nisn',
                    nama = '$nama',
                    alamat = '$alamat'")or die('Ada kesalahan pada query  : '.mysqli_error($connect));
            }
            if ($query) {
                header("location: index.php?alert=1");
            }
        }
    }
    elseif ($_GET['act']=='hapus') {
        $id = $_GET['id'];
        if (isset($id)) {
            $query = "SELECT foto FROM tbl_siswa WHERE id_siswa='$id'";
            $hapus = mysqli_query($connect, $query);
            $r = mysqli_fetch_array($hapus);
            if ($r['foto']!=''){
                $namafile = $r['foto'];
                unlink("foto/".$namafile); 
            }
            $query = mysqli_query($connect, "DELETE FROM tbl_siswa WHERE id_siswa='$id'")or die('Ada kesalahan pada query delete : '.mysqli_error($connect));

            if ($query) {
                header("location: index.php?alert=1");
            }
        }
    }
?>