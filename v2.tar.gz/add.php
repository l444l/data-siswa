<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Tambah Data Siswa</title>

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;500;700&display=swap" rel="stylesheet">

  <!-- Bootstrap 5 -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

  <!-- Font Awesome -->
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">

  <!-- AOS -->
  <link href="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.css" rel="stylesheet">

  <!-- Custom Style -->
  <style>
    body {
      background-color: #0f111a;
      color: #fff;
      font-family: 'Poppins', sans-serif;
    }

    .neumorphic {
      background: #1a1c27;
      border-radius: 16px;
      box-shadow: 8px 8px 16px #0a0b10,
                  -8px -8px 16px #1f2233;
      padding: 40px;
      max-width: 600px;
      margin: auto;
      margin-top: 80px;
    }

    .btn-custom {
      border-radius: 12px;
      transition: all 0.3s ease;
      box-shadow: 0 4px 15px rgba(0,0,0,0.2);
    }

    .btn-custom:hover {
      transform: translateY(-2px);
      box-shadow: 0 6px 25px rgba(0,0,0,0.3);
    }

    h2.title {
      text-align: center;
      margin-bottom: 30px;
      font-weight: bold;
    }

    a.back-btn {
      color: #ccc;
      text-decoration: none;
      display: inline-block;
      margin-bottom: 20px;
    }

    a.back-btn:hover {
      text-decoration: underline;
    }
  </style>
</head>
<body>

<div class="container">
  <div data-aos="fade-up">
    <a href="index.php" class="back-btn">
      <i class="fas fa-arrow-left me-2"></i>Kembali ke Beranda
    </a>

    <div class="neumorphic text-light">
      <h2 class="title">Tambah Data Siswa</h2>

      <form action="process.php?act=simpan" method="post" enctype="multipart/form-data" name="form" target="_self">
        <div class="mb-3">
          <label for="foto" class="form-label">Foto</label><br>
          <img id="output" width="150" class="img-thumbnail mb-2 d-block" />
          <input type="file" name="foto" class="form-control" onchange="loadFile(event)" required>
        </div>

        <div class="mb-3">
          <label for="nisn" class="form-label">NISN</label>
          <input type="text" name="nisn" class="form-control" required>
        </div>

        <div class="mb-3">
          <label for="nama" class="form-label">Nama Lengkap</label>
          <input type="text" name="nama" class="form-control" required>
        </div>

        <div class="mb-3">
          <label for="alamat" class="form-label">Alamat</label>
          <input type="text" name="alamat" class="form-control" required>
        </div>

        <div class="mt-4">
          <button class="btn btn-primary btn-custom w-100" type="submit" name="submit">
            <i class="fas fa-save me-1"></i> Simpan
          </button>
        </div>
      </form>
    </div>
  </div>
</div>

<!-- Bootstrap JS + AOS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.js"></script>
<script>
  AOS.init();

  var loadFile = function(event) {
    var image = document.getElementById('output');
    image.src = URL.createObjectURL(event.target.files[0]);
  };
</script>

</body>
</html>
